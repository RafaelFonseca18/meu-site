﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnsoma = New System.Windows.Forms.Button()
        Me.txtnum1 = New System.Windows.Forms.TextBox()
        Me.btnsub = New System.Windows.Forms.Button()
        Me.btnmult = New System.Windows.Forms.Button()
        Me.btndiv = New System.Windows.Forms.Button()
        Me.txtnum2 = New System.Windows.Forms.TextBox()
        Me.txtres = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnsoma
        '
        Me.btnsoma.Location = New System.Drawing.Point(235, 108)
        Me.btnsoma.Name = "btnsoma"
        Me.btnsoma.Size = New System.Drawing.Size(75, 23)
        Me.btnsoma.TabIndex = 0
        Me.btnsoma.Text = "+"
        Me.btnsoma.UseVisualStyleBackColor = True
        '
        'txtnum1
        '
        Me.txtnum1.Location = New System.Drawing.Point(112, 105)
        Me.txtnum1.Name = "txtnum1"
        Me.txtnum1.Size = New System.Drawing.Size(100, 20)
        Me.txtnum1.TabIndex = 1
        '
        'btnsub
        '
        Me.btnsub.Location = New System.Drawing.Point(235, 137)
        Me.btnsub.Name = "btnsub"
        Me.btnsub.Size = New System.Drawing.Size(75, 23)
        Me.btnsub.TabIndex = 2
        Me.btnsub.Text = "-"
        Me.btnsub.UseVisualStyleBackColor = True
        '
        'btnmult
        '
        Me.btnmult.Location = New System.Drawing.Point(235, 166)
        Me.btnmult.Name = "btnmult"
        Me.btnmult.Size = New System.Drawing.Size(75, 23)
        Me.btnmult.TabIndex = 3
        Me.btnmult.Text = "*"
        Me.btnmult.UseVisualStyleBackColor = True
        '
        'btndiv
        '
        Me.btndiv.Location = New System.Drawing.Point(235, 195)
        Me.btndiv.Name = "btndiv"
        Me.btndiv.Size = New System.Drawing.Size(75, 23)
        Me.btndiv.TabIndex = 4
        Me.btndiv.Text = "/"
        Me.btndiv.UseVisualStyleBackColor = True
        '
        'txtnum2
        '
        Me.txtnum2.Location = New System.Drawing.Point(112, 131)
        Me.txtnum2.Name = "txtnum2"
        Me.txtnum2.Size = New System.Drawing.Size(100, 20)
        Me.txtnum2.TabIndex = 5
        '
        'txtres
        '
        Me.txtres.Location = New System.Drawing.Point(74, 157)
        Me.txtres.Name = "txtres"
        Me.txtres.Size = New System.Drawing.Size(100, 20)
        Me.txtres.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 108)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Digite o 1 número:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 131)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(93, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Digite o 2 número:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(13, 160)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Resposta:"
        '
        'btnclear
        '
        Me.btnclear.Location = New System.Drawing.Point(235, 224)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(75, 23)
        Me.btnclear.TabIndex = 10
        Me.btnclear.Text = "CLEAR"
        Me.btnclear.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(343, 284)
        Me.Controls.Add(Me.btnclear)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtres)
        Me.Controls.Add(Me.txtnum2)
        Me.Controls.Add(Me.btndiv)
        Me.Controls.Add(Me.btnmult)
        Me.Controls.Add(Me.btnsub)
        Me.Controls.Add(Me.txtnum1)
        Me.Controls.Add(Me.btnsoma)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnsoma As System.Windows.Forms.Button
    Friend WithEvents txtnum1 As System.Windows.Forms.TextBox
    Friend WithEvents btnsub As System.Windows.Forms.Button
    Friend WithEvents btnmult As System.Windows.Forms.Button
    Friend WithEvents btndiv As System.Windows.Forms.Button
    Friend WithEvents txtnum2 As System.Windows.Forms.TextBox
    Friend WithEvents txtres As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnclear As System.Windows.Forms.Button

End Class
