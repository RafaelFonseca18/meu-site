﻿Public Class Form1

    Public Function soma(ByVal n1 As Single, ByVal n2 As Single) As Single
        Return n1 + n2
    End Function

    Public Function menos(ByVal n1 As Single, ByVal n2 As Single) As Single
        Return n1 - n2
    End Function

    Public Function mult(ByVal n1 As Single, ByVal n2 As Single) As Single
        Return n1 * n2
    End Function

    Public Function div(ByVal n1 As Single, ByVal n2 As Single) As Single
        Return n1 / n2
    End Function

    Public Sub entrada_soma()
        Dim res As Single
        res = soma(CSng(txtnum1.Text), CSng(txtnum2.Text))
        txtres.Text = res.ToString
    End Sub

    Public Sub entrada_menos()
        Dim res As Single
        res = menos(CSng(txtnum1.Text), CSng(txtnum2.Text))
        txtres.Text = res.ToString
    End Sub

    Public Sub entrada_mult()
        Dim res As Single
        res = mult(CSng(txtnum1.Text), CSng(txtnum2.Text))
        txtres.Text = res.ToString
    End Sub

    Public Sub entrada_div()
        Dim res As Single
        res = div(CSng(txtnum1.Text), CSng(txtnum2.Text))
        txtres.Text = res.ToString
    End Sub

    Public Sub clear()
        txtnum1.Clear()
        txtnum2.Clear()
        txtres.Clear()
    End Sub
    Private Sub btnsoma_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsoma.Click
        entrada_soma()
    End Sub

    Private Sub btnsub_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsub.Click
        entrada_menos()
    End Sub

    Private Sub btnmult_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnmult.Click
        entrada_mult()
    End Sub

    Private Sub btndiv_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndiv.Click
        entrada_div()
    End Sub

    Private Sub btnclear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclear.Click
        clear()
    End Sub
End Class
