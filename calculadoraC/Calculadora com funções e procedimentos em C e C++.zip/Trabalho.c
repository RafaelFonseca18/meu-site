/*1� ponto*/
#include <conio.h>
#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
/*3� ponto*/
void principal();
char menu();
void entrada_soma();
float somar (float n1, float n2);
void entrada_sub();
float sub (float n1, float n2);
void entrada_mult();
float mult (float n1, float n2); 
void entrada_divi();
float divi (float n1, float n2); 



/*4� ponto*/
int main (){
	principal();
	return 0;
}
/*5� ponto*/

char menu(){
	printf ("----------------------------------\n");
	printf ("\tSUPER CALCULADORA\n");
	printf ("----------------------------------\n");
	printf ("<A> Somar\n");
	printf ("<B> Subtrair\n");
	printf ("<C> Multiplicar\n");
	printf ("<D> Dividir\n");
	printf ("<S> Sair\n\n");
	printf ("Escolha (A..D,S):");
	
	return getche();
}

float somar (float n1, float n2){
	return n1 + n2;	
}

void entrada_soma(){
	float num1, num2;
	system("cls");
	printf ("SOMA\n");
	printf ("----------------------------------\n");
	printf ("1� N�mero:");
	scanf ("%f", &num1);
	printf ("2� N�mero:");
	scanf ("%f", &num2);
	printf ("A soma de %.1f + %.1f = %.f", num1, num2, somar(num1, num2));
	getch();
	system("cls");
	return principal();
}

float sub (float n1, float n2){
	return n1 - n2;	
}
void entrada_sub(){
	float num1, num2;
	system("cls");
	printf ("SUB\n");
	printf ("----------------------------------\n");
	printf ("1� N�mero:");
	scanf ("%f", &num1);
	printf ("2� N�mero:");
	scanf ("%f", &num2);
	printf ("A soma de %.1f - %.1f = %.f", num1, num2, sub(num1, num2));
	getch();
	system("cls");
	return principal();
}

float mult (float n1, float n2){
	return n1 * n2;	
}
void entrada_mult(){
	float num1, num2;
	system("cls");
	printf ("MULT\n");
	printf ("----------------------------------\n");
	printf ("1� N�mero:");
	scanf ("%f", &num1);
	printf ("2� N�mero:");
	scanf ("%f", &num2);
	printf ("A soma de %.1f * %.1f = %.f", num1, num2, mult(num1, num2));
	getch();
	system("cls");
	return principal();

}
float divi (float n1, float n2){
	return n1 / n2;
}
void entrada_divi(){
	float num1, num2;
	system("cls");
	printf ("DIV\n");
	printf ("----------------------------------\n");
	printf ("1� N�mero:");
	scanf ("%f", &num1);
	printf ("2� N�mero:");
	scanf ("%f", &num2);
	printf ("A soma de %.1f / %.1f = %.3f", num1, num2, divi(num1, num2));
	getch();
	system("cls");
	return principal();

}
void principal(){
	char opc;
	setlocale (LC_ALL, "ptb");
	opc = menu();
	switch (opc){
		case 'A':   entrada_soma();
					break;
					
		case 'a':   entrada_soma();
					break;
					
					
        case 'B':   entrada_sub();
                    break;
                    
        case 'b':   entrada_sub();
                    break;
                    
                    
        case 'C':  entrada_mult();
		            break;   
		case 'c':  entrada_mult();
		            break; 			
					
					  
		case 'D': entrada_divi();
		            break;    
		            
		case 'd': entrada_divi();
		            break;            
		            
		            
		            
		case 'S': 
		system("cls");
		char escolha;
		printf("voce tem certeza de que deseja sair?");
		scanf("%c", &escolha);
		if(escolha =='S' || escolha =='s'){
			printf("saindo do programa\n");
				system("cls");
			exit(0);
	}
		else if(escolha =='N' || escolha =='n'){
			system("cls");
				return principal();
		}
		
		case 's': 
		system("cls");
		char opcao;
		printf("voce tem certeza de que deseja sair?");
		scanf("%c", &escolha);
		system("cls");
		if(opcao =='S' ||  opcao=='s'){
			system("cls");
			exit(0);
			
	}
        else if(escolha =='N' || escolha =='n'){
			system("cls");
			return principal();
			exit(0);
		}
	
		
		
					
	  }
  } 


